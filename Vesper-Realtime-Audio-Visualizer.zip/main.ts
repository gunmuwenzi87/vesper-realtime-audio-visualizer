import './style.css';

type Language = 'en' | 'zh';
type ThemeName = 'aurora' | 'cyber' | 'sunset' | 'ultraviolet';
type Theme = { colors: [string, string, string]; rgb: [string, string, string] };

const translations = {
  en: {
    themeGroup: 'Color theme', languageAria: 'Switch interface language', dropOverlay: 'DROP TO LOAD TRACK', beatOff: 'BEAT DETECTOR OFF', pauseTip: 'Pause track', unmuteTip: 'Unmute', exportButton: 'Export PNG', exportTip: 'Save a high-resolution image of the current visualization', exportSuccess: 'PNG snapshot saved.', exportFailed: 'The visualization could not be exported.', fileLoadFailed: 'The selected file could not be opened.',
    controlsAria: 'Visualizer controls', brandSubtitle: 'AUDIO VISUALIZER', introEyebrow: 'SOUND / IN MOTION', introTitle: 'Listen<br>in color.', introCopy: 'Give a track a shape. Every frequency leaves a trace.', trackSection: 'YOUR TRACK', dropTip: 'Choose a local audio file, or drop one here', dropTitle: 'Drop audio here', dropOr: 'or choose a local file', localFile: 'LOCAL AUDIO FILE', replaceTip: 'Choose a different audio file', themeSection: 'NEON PALETTE', themeAuroraTip: 'Cool teal and blue tones', themeAurora: 'Aurora', themeCyberTip: 'Electric cyan and acid green', themeCyber: 'Cyber', themeSunsetTip: 'Warm coral and gold tones', themeSunset: 'Afterglow', themeVioletTip: 'Deep violet and pink tones', themeUltraviolet: 'Ultraviolet', tuningSection: 'SIGNAL TUNING', sensitivityLabel: 'Sensitivity', sensitivityTip: 'Adjust how strongly audio shapes the visuals', subtleLabel: 'SUBTLE', intenseLabel: 'INTENSE', trailsLabel: 'Waveform trails', trailsHint: 'Let light linger on the canvas', trailsTip: 'Toggle the motion trail effect', beatLabel: 'Beat detection', beatHint: 'Pulse on low-frequency hits', beatTip: 'Toggle low-frequency beat detection', engineFooter: 'WEB AUDIO ENGINE', workspaceLabel: 'WORKSPACE', visualizerLabel: 'VISUALIZER', statusWaiting: 'WAITING FOR AUDIO', languageTip: 'Switch to Simplified Chinese', uploadTip: 'Load an audio file from this device', uploadButton: 'Load a track', visualAria: 'Audio visualization canvas', visualEyebrow: 'LIVE FREQUENCY ANALYSIS', visualTitle: 'Sound, made visible.', beatWaiting: 'BEAT DETECTOR ON', canvasAria: 'Animated audio spectrum and circular waveform', emptyOverline: 'A CANVAS FOR YOUR SOUND', emptyTitle: 'Start with a track.', emptyCopy: 'Choose a local audio file to bring the spectrum to life.', emptyAction: 'Choose audio file', spectrumLabel: 'SPECTRUM / RADIAL WAVE', noTrackLoaded: 'NO TRACK LOADED', frequencyLabel: '20 Hz', highFrequencyLabel: '20 kHz', playerAria: 'Audio player controls', restartTip: 'Restart track', playTip: 'Play or pause', noTrack: 'No track selected', readyToListen: 'LOAD A TRACK TO BEGIN', seekTip: 'Seek through the track', muteTip: 'Mute or unmute', volumeTip: 'Adjust volume', footerLocal: 'Audio stays on your device.', footerTech: 'WEB AUDIO API', fatalTitle: 'The audio engine could not start', fatalCopy: 'Try refreshing the page.', playing: 'NOW PLAYING', paused: 'PAUSED', ready: 'READY TO PLAY', waiting: 'WAITING FOR AUDIO', beatDetected: 'BEAT DETECTED', chooseAudio: 'Please choose an audio file.', unsupportedFile: 'That file does not look like supported audio.', loadFailed: 'This audio file could not be decoded by the browser.', playFailed: 'Playback could not start. Try another audio format.', audioUnavailable: 'Web Audio is unavailable in this browser.', contextFailed: 'The audio engine could not be initialized.', genericError: 'Something went wrong while preparing the audio.', fileLoaded: 'Track ready to play.', fileChanged: 'Audio file changed.', volumeMuted: 'Muted', volumeRestored: 'Volume restored', noDuration: 'LIVE',
  },
  zh: {
    themeGroup: '配色方案', languageAria: '切换界面语言', dropOverlay: '释放文件以加载音轨', beatOff: '节拍检测已关闭', pauseTip: '暂停音轨', unmuteTip: '取消静音', exportButton: '导出 PNG', exportTip: '保存当前可视化画面的高清图片', exportSuccess: 'PNG 快照已保存。', exportFailed: '无法导出当前可视化画面。', fileLoadFailed: '无法打开所选文件。',
    controlsAria: '可视化控制面板', brandSubtitle: '音频可视化工具', introEyebrow: '声音 / 流动之中', introTitle: '让聆听<br>拥有色彩。', introCopy: '为一段音乐赋予形状，让每个频率留下痕迹。', trackSection: '你的音轨', dropTip: '选择本地音频文件，或将文件拖到这里', dropTitle: '将音频拖到这里', dropOr: '或选择本地文件', localFile: '本地音频文件', replaceTip: '选择另一个音频文件', themeSection: '霓虹配色', themeAuroraTip: '清凉的青绿色与蓝色', themeAurora: '极光', themeCyberTip: '电光青与荧光绿', themeCyber: '赛博', themeSunsetTip: '温暖的珊瑚色与金色', themeSunset: '余晖', themeVioletTip: '深紫与粉色调', themeUltraviolet: '紫外线', tuningSection: '信号调节', sensitivityLabel: '灵敏度', sensitivityTip: '调整音频对画面变化的影响强度', subtleLabel: '柔和', intenseLabel: '强烈', trailsLabel: '波形残影', trailsHint: '让光迹停留在画布上', trailsTip: '开关动态拖尾效果', beatLabel: '节拍检测', beatHint: '低频节拍触发脉冲', beatTip: '开关低频节拍检测', engineFooter: 'WEB AUDIO 音频引擎', workspaceLabel: '工作区', visualizerLabel: '可视化', statusWaiting: '等待音频', languageTip: 'Switch to English', uploadTip: '从此设备加载音频文件', uploadButton: '加载音轨', visualAria: '音频可视化画布', visualEyebrow: '实时频率分析', visualTitle: '让声音，看得见。', beatWaiting: '节拍检测已开启', canvasAria: '动态音频频谱与环形波形', emptyOverline: '为你的声音准备的画布', emptyTitle: '从一段音乐开始。', emptyCopy: '选择本地音频文件，让频谱鲜活起来。', emptyAction: '选择音频文件', spectrumLabel: '频谱 / 环形波形', noTrackLoaded: '尚未加载音轨', frequencyLabel: '20 赫兹', highFrequencyLabel: '20 千赫兹', playerAria: '音频播放控制', restartTip: '从头播放', playTip: '播放或暂停', noTrack: '尚未选择音轨', readyToListen: '加载音轨以开始播放', seekTip: '拖动以定位播放进度', muteTip: '静音或取消静音', volumeTip: '调节音量', footerLocal: '音频仅在本机处理。', footerTech: 'WEB AUDIO API', fatalTitle: '音频引擎无法启动', fatalCopy: '请尝试刷新页面。', playing: '正在播放', paused: '已暂停', ready: '准备播放', waiting: '等待音频', beatDetected: '检测到节拍', chooseAudio: '请选择音频文件。', unsupportedFile: '该文件格式似乎不是受支持的音频。', loadFailed: '浏览器无法解码此音频文件。', playFailed: '无法开始播放，请尝试其他音频格式。', audioUnavailable: '此浏览器不支持 Web Audio。', contextFailed: '无法初始化音频引擎。', genericError: '准备音频时发生错误。', fileLoaded: '音轨已准备好播放。', fileChanged: '音频文件已更换。', volumeMuted: '已静音', volumeRestored: '已恢复音量', noDuration: '实时',
  },
} satisfies Record<Language, Record<string, string>>;

type TranslationKey = keyof typeof translations.en;
type MissingChineseKeys = Exclude<TranslationKey, keyof typeof translations.zh>;
const localeCoverage: MissingChineseKeys extends never ? true : never = true;
void localeCoverage;

const themes: Record<ThemeName, Theme> = {
  aurora: { colors: ['#58f0d0', '#55a9ff', '#c1a1ff'], rgb: ['88,240,208', '85,169,255', '193,161,255'] },
  cyber: { colors: ['#48efff', '#a6ff4d', '#17a7dd'], rgb: ['72,239,255', '166,255,77', '23,167,221'] },
  sunset: { colors: ['#ff927c', '#ffd071', '#ff5d94'], rgb: ['255,146,124', '255,208,113', '255,93,148'] },
  ultraviolet: { colors: ['#b88cff', '#ff80d8', '#706aff'], rgb: ['184,140,255', '255,128,216', '112,106,255'] },
};

function required<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Required interface element not found: ${selector}`);
  return element;
}

const elements = {
  audioFile: required<HTMLInputElement>('#audioFile'), dropZone: required<HTMLButtonElement>('#dropZone'), loadedTrack: required<HTMLDivElement>('#loadedTrack'), fileName: required<HTMLElement>('#fileName'), fileMeta: required<HTMLElement>('#fileMeta'), replaceFileBtn: required<HTMLButtonElement>('#replaceFileBtn'), sensitivity: required<HTMLInputElement>('#sensitivity'), sensitivityValue: required<HTMLOutputElement>('#sensitivityValue'), trailsToggle: required<HTMLButtonElement>('#trailsToggle'), beatToggle: required<HTMLButtonElement>('#beatToggle'), languageToggle: required<HTMLButtonElement>('#languageToggle'), visualStatus: required<HTMLDivElement>('#visualStatus'), uploadButton: required<HTMLButtonElement>('#uploadButton'), visualFrame: required<HTMLDivElement>('#visualFrame'), canvas: required<HTMLCanvasElement>('#visualCanvas'), emptyState: required<HTMLDivElement>('#emptyState'), emptyUploadButton: required<HTMLButtonElement>('#emptyUploadButton'), beatBadge: required<HTMLDivElement>('#beatBadge'), beatStatus: required<HTMLElement>('#beatStatus'), canvasTime: required<HTMLElement>('#canvasTime'), canvasDuration: required<HTMLElement>('#canvasDuration'), canvasTrackState: required<HTMLElement>('#canvasTrackState'), playerTrackName: required<HTMLElement>('#playerTrackName'), playerTrackState: required<HTMLElement>('#playerTrackState'), restartButton: required<HTMLButtonElement>('#restartButton'), playButton: required<HTMLButtonElement>('#playButton'), playIcon: required<SVGSVGElement>('#playIcon'), seekSlider: required<HTMLInputElement>('#seekSlider'), currentTime: required<HTMLElement>('#currentTime'), durationTime: required<HTMLElement>('#durationTime'), muteButton: required<HTMLButtonElement>('#muteButton'), volumeIcon: required<SVGSVGElement>('#volumeIcon'), volumeSlider: required<HTMLInputElement>('#volumeSlider'), audio: required<HTMLAudioElement>('#audioElement'), toastRegion: required<HTMLDivElement>('#toastRegion'), fatalPanel: required<HTMLDivElement>('#fatalPanel'), fatalMessage: required<HTMLElement>('#fatalMessage'),
};

const exportButton = required<HTMLButtonElement>('#exportButton');
const dropOverlay = required<HTMLDivElement>('#dropOverlay');

const canvasContext = elements.canvas.getContext('2d', { alpha: false, desynchronized: true });
if (!canvasContext) throw new Error('Canvas 2D is unavailable.');
const ctx = canvasContext;
const listenerController = new AbortController();
const { signal } = listenerController;

let language: Language = 'en';
let activeTheme: ThemeName = 'aurora';
let sensitivity = Number(elements.sensitivity.value);
let trailsEnabled = true;
let beatEnabled = true;
let audioContext: AudioContext | null = null;
let analyser: AnalyserNode | null = null;
let gainNode: GainNode | null = null;
let sourceNode: MediaElementAudioSourceNode | null = null;
let frequencyData: Uint8Array<ArrayBuffer> | null = null;
let waveformData: Uint8Array<ArrayBuffer> | null = null;
let objectUrl: string | null = null;
let animationFrame = 0;
let toastTimeout = 0;
let beatTimeout = 0;
let downloadTimeout = 0;
let activeToastKey: TranslationKey | null = null;
let exportedImageUrl: string | null = null;
let trackDurationText = '';
let resizeObserver: ResizeObserver | null = null;
let isDisposed = false;
let lastFrameTime = 0;
let canvasViewWidth = 0;
let canvasViewHeight = 0;
let beatLevel = 0;
let beatAverage = 0;
let beatPulse = 0;
let lastBeatAt = 0;

function t(key: TranslationKey): string {
  return translations[language][key];
}

function isTranslationKey(key: string): key is TranslationKey {
  return Object.hasOwn(translations.en, key);
}

function applyLanguage(): void {
  document.documentElement.lang = language === 'en' ? 'en' : 'zh-CN';
  document.querySelectorAll<HTMLElement>('[data-i18n]').forEach((element) => {
    const key = element.dataset.i18n;
    if (key && isTranslationKey(key)) element.innerHTML = t(key);
  });
  document.querySelectorAll<HTMLElement>('[data-i18n-title]').forEach((element) => {
    const key = element.dataset.i18nTitle;
    if (key && isTranslationKey(key)) element.title = t(key);
  });
  document.querySelectorAll<HTMLElement>('[data-i18n-aria]').forEach((element) => {
    const key = element.dataset.i18nAria;
    if (key && isTranslationKey(key)) element.setAttribute('aria-label', t(key));
  });
  elements.languageToggle.textContent = language === 'en' ? '简体中文' : 'English';
  document.title = language === 'en' ? 'VESPER — Audio Visualizer' : 'VESPER — 音频可视化';
  updatePlaybackLabels();
  updateBeatLabel();
  updateMuteControl();
  updateFileMetadata();
  updateTime();
  if (activeToastKey) elements.toastRegion.textContent = t(activeToastKey);
}

function showToast(key: TranslationKey): void {
  window.clearTimeout(toastTimeout);
  activeToastKey = key;
  elements.toastRegion.textContent = t(key);
  elements.toastRegion.classList.add('is-visible');
  toastTimeout = window.setTimeout(() => {
    elements.toastRegion.classList.remove('is-visible');
    activeToastKey = null;
  }, 3100);
}

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const wholeSeconds = Math.floor(seconds);
  const hours = Math.floor(wholeSeconds / 3600);
  const minutes = Math.floor((wholeSeconds % 3600) / 60);
  const remainder = wholeSeconds % 60;
  return hours > 0
    ? `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remainder).padStart(2, '0')}`
    : `${String(minutes).padStart(2, '0')}:${String(remainder).padStart(2, '0')}`;
}

function setEngineStatus(status: 'waiting' | 'ready' | 'playing' | 'paused'): void {
  const label = elements.visualStatus.querySelector('span:last-child');
  if (label) label.textContent = t(status === 'waiting' ? 'statusWaiting' : status);
  elements.visualStatus.classList.toggle('is-active', status === 'playing');
}

function updatePlaybackLabels(): void {
  const isPlaying = !elements.audio.paused && !elements.audio.ended;
  const playLabel = isPlaying ? t('playing') : objectUrl ? (elements.audio.currentTime > 0 ? t('paused') : t('ready')) : t('waiting');
  elements.playerTrackState.textContent = playLabel.toUpperCase();
  elements.canvasTrackState.textContent = playLabel.toUpperCase();
  const titleKey = isPlaying ? 'pauseTip' : 'playTip';
  elements.playButton.title = t(titleKey);
  elements.playButton.setAttribute('aria-label', t(isPlaying ? 'pauseTip' : 'playTip'));
  elements.playButton.setAttribute('aria-pressed', String(isPlaying));
  elements.playIcon.innerHTML = isPlaying ? '<path d="M6 5h4v12H6zm7 0h4v12h-4z" />' : '<path d="m8 5 9 6-9 6z" />';
  setEngineStatus(isPlaying ? 'playing' : objectUrl ? (elements.audio.currentTime > 0 ? 'paused' : 'ready') : 'waiting');
}

function updateBeatLabel(): void {
  elements.beatStatus.textContent = t(beatEnabled ? 'beatWaiting' : 'beatOff');
  elements.beatBadge.classList.toggle('is-disabled', !beatEnabled);
}

function updateTime(): void {
  const current = elements.audio.currentTime;
  const duration = elements.audio.duration;
  elements.currentTime.textContent = formatTime(current);
  elements.canvasTime.textContent = formatTime(current);
  if (Number.isFinite(duration)) {
    elements.durationTime.textContent = formatTime(duration);
    elements.canvasDuration.textContent = formatTime(duration);
    elements.seekSlider.value = String(duration > 0 ? Math.round((current / duration) * 1000) : 0);
  } else {
    const unknownDuration = objectUrl ? t('noDuration') : '00:00';
    elements.durationTime.textContent = unknownDuration;
    elements.canvasDuration.textContent = unknownDuration;
  }
}

function updateFileMetadata(): void {
  const localLabel = language === 'en' ? t('localFile').toUpperCase() : t('localFile');
  elements.fileMeta.textContent = trackDurationText ? `${trackDurationText} · ${localLabel}` : localLabel;
}

function updateMuteControl(): void {
  const isMuted = elements.audio.muted || Number(elements.volumeSlider.value) === 0;
  const label = isMuted
    ? t('unmuteTip')
    : t('muteTip');
  elements.muteButton.title = label;
  elements.muteButton.setAttribute('aria-label', label);
  elements.volumeIcon.innerHTML = isMuted
    ? '<path d="M3 8v4h3l4 3V5L6 8H3zm10 0 5 5m0-5-5 5" />'
    : '<path d="M3 8v4h3l4 3V5L6 8H3zm10-1a4 4 0 0 1 0 6m2-8a7 7 0 0 1 0 10" />';
}

function applyTheme(themeName: ThemeName): void {
  activeTheme = themeName;
  const theme = themes[themeName];
  document.documentElement.style.setProperty('--accent', theme.colors[0]);
  document.documentElement.style.setProperty('--accent-rgb', theme.rgb[0]);
  document.querySelectorAll<HTMLButtonElement>('.theme-card').forEach((button) => {
    button.classList.toggle('is-selected', button.dataset.theme === themeName);
  });
}

function getAudioGraph(): AudioContext {
  if (audioContext && audioContext.state !== 'closed') return audioContext;
  const AudioContextConstructor = window.AudioContext;
  if (!AudioContextConstructor) throw new Error(t('audioUnavailable'));
  const context = new AudioContextConstructor();
  try {
    const source = context.createMediaElementSource(elements.audio);
    const audioAnalyser = context.createAnalyser();
    const outputGain = context.createGain();
    audioAnalyser.fftSize = 4096;
    audioAnalyser.smoothingTimeConstant = 0.78;
    audioAnalyser.minDecibels = -92;
    audioAnalyser.maxDecibels = -12;
    outputGain.gain.value = Number(elements.volumeSlider.value);
    source.connect(audioAnalyser);
    audioAnalyser.connect(outputGain);
    outputGain.connect(context.destination);
    audioContext = context;
    sourceNode = source;
    analyser = audioAnalyser;
    gainNode = outputGain;
    frequencyData = new Uint8Array(new ArrayBuffer(audioAnalyser.frequencyBinCount));
    waveformData = new Uint8Array(new ArrayBuffer(audioAnalyser.fftSize));
    return context;
  } catch (error) {
    void context.close().catch(() => undefined);
    throw error;
  }
}

function updateCanvasSize(): void {
  const bounds = elements.visualFrame.getBoundingClientRect();
  canvasViewWidth = bounds.width;
  canvasViewHeight = bounds.height;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(1, Math.round(bounds.width * ratio));
  const height = Math.max(1, Math.round(bounds.height * ratio));
  if (elements.canvas.width === width && elements.canvas.height === height) {
    drawFrame(performance.now(), false);
    return;
  }
  elements.canvas.width = width;
  elements.canvas.height = height;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  drawFrame(performance.now(), false);
}

function drawFrame(timestamp: number, scheduleNext = true): void {
  if (scheduleNext) animationFrame = 0;
  if (isDisposed) return;
  if (scheduleNext && document.hidden) return;
  const width = canvasViewWidth;
  const height = canvasViewHeight;
  if (width < 2 || height < 2) return;
  const theme = themes[activeTheme];
  const delta = lastFrameTime ? Math.min((timestamp - lastFrameTime) / 1000, 0.05) : 0.016;
  lastFrameTime = timestamp;
  const isPlaying = !elements.audio.paused && !elements.audio.ended;

  if (analyser && frequencyData && waveformData && isPlaying) {
    analyser.getByteFrequencyData(frequencyData);
    analyser.getByteTimeDomainData(waveformData);
  }

  ctx.save();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = trailsEnabled ? 'rgba(7, 10, 18, 0.22)' : '#070a12';
  ctx.fillRect(0, 0, width, height);

  const centerX = width * 0.5;
  const centerY = height * 0.47;
  const baseRadius = Math.min(width * 0.205, height * 0.295);
  const pulseScale = 1 + beatPulse * 0.035;
  const radius = baseRadius * pulseScale;
  const samples = waveformData;
  const bins = frequencyData;

  const halo = ctx.createRadialGradient(centerX, centerY, radius * 0.55, centerX, centerY, radius * 2.15);
  halo.addColorStop(0, `rgba(${theme.rgb[0]}, ${0.055 + beatPulse * 0.045})`);
  halo.addColorStop(0.55, `rgba(${theme.rgb[1]}, 0.035)`);
  halo.addColorStop(1, 'rgba(8, 11, 20, 0)');
  ctx.fillStyle = halo;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = 'rgba(178, 195, 228, 0.055)';
  ctx.lineWidth = 1;
  for (const ringScale of [0.69, 1, 1.36]) {
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * ringScale, 0, Math.PI * 2);
    ctx.stroke();
  }

  const barCount = 112;
  const spectrumBottom = height * 0.91;
  const spectrumTop = height * 0.77;
  const spectrumWidth = Math.min(width * 0.72, 850);
  const barGap = Math.max(2, width * 0.0028);
  const barWidth = Math.max(1, (spectrumWidth - barGap * barCount) / barCount);
  const startX = centerX - spectrumWidth / 2;
  ctx.globalCompositeOperation = 'lighter';
  for (let index = 0; index < barCount; index += 1) {
    const dataIndex = Math.min(bins?.length ? Math.floor(Math.pow(index / barCount, 1.65) * bins.length * 0.72) : 0, (bins?.length ?? 1) - 1);
    const magnitude = bins ? bins[dataIndex] / 255 : 0;
    const shaped = Math.pow(magnitude * sensitivity, 0.88);
    const idleWave = isPlaying ? 0 : (Math.sin(timestamp / 1100 + index * 0.32) + 1) * 0.012;
    const barHeight = Math.max(2, (shaped * 0.88 + idleWave) * (spectrumBottom - spectrumTop));
    const x = startX + index * (barWidth + barGap);
    const color = theme.colors[index % theme.colors.length];
    const gradient = ctx.createLinearGradient(0, spectrumBottom - barHeight, 0, spectrumBottom);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, `rgba(${theme.rgb[index % 3]}, 0.12)`);
    ctx.fillStyle = gradient;
    ctx.shadowColor = color;
    ctx.shadowBlur = isPlaying ? 10 : 3;
    ctx.globalAlpha = 0.48 + Math.min(0.48, shaped * 0.85);
    ctx.beginPath();
    ctx.roundRect(x, spectrumBottom - barHeight, barWidth, barHeight, Math.min(barWidth / 2, 4));
    ctx.fill();
  }
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 1;

  const pointCount = 256;
  for (let layer = 2; layer >= 0; layer -= 1) {
    const layerRadius = radius * (1 + layer * 0.032);
    ctx.beginPath();
    for (let index = 0; index <= pointCount; index += 1) {
      const angle = (index / pointCount) * Math.PI * 2 - Math.PI / 2;
      const sampleIndex = samples ? Math.floor((index / pointCount) * samples.length) % samples.length : 0;
      const centered = samples ? (samples[sampleIndex] - 128) / 128 : 0;
      const frequencyIndex = bins ? Math.floor((index / pointCount) * bins.length * 0.42) : 0;
      const bassLift = bins ? (bins[frequencyIndex] / 255) * 0.13 * sensitivity : 0;
      const ambient = isPlaying ? 0 : Math.sin(timestamp / 850 + angle * 3) * 0.008;
      const waveRadius = layerRadius + centered * radius * (0.18 + sensitivity * 0.065) + bassLift * radius + ambient * radius;
      const x = centerX + Math.cos(angle) * waveRadius;
      const y = centerY + Math.sin(angle) * waveRadius;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.strokeStyle = theme.colors[2 - layer];
    ctx.lineWidth = layer === 0 ? 1.6 : layer === 1 ? 1.2 : 0.85;
    ctx.globalAlpha = layer === 0 ? 0.92 : layer === 1 ? 0.38 : 0.18;
    ctx.shadowColor = theme.colors[2 - layer];
    ctx.shadowBlur = layer === 0 ? 20 : 11;
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;

  const centerGlow = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius * 0.52);
  centerGlow.addColorStop(0, `rgba(${theme.rgb[1]}, 0.095)`);
  centerGlow.addColorStop(0.7, `rgba(${theme.rgb[0]}, 0.025)`);
  centerGlow.addColorStop(1, 'rgba(7, 10, 18, 0)');
  ctx.fillStyle = centerGlow;
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius * 0.52, 0, Math.PI * 2);
  ctx.fill();

  if (beatEnabled && isPlaying && bins) {
    const lowBinEnd = Math.max(2, Math.floor(bins.length * 0.035));
    let total = 0;
    for (let index = 1; index < lowBinEnd; index += 1) total += bins[index] / 255;
    beatLevel = total / lowBinEnd;
    beatAverage = beatAverage * 0.94 + beatLevel * 0.06;
    const now = performance.now();
    if (beatLevel > Math.max(0.19, beatAverage * 1.62) && beatLevel > 0.24 && now - lastBeatAt > 260) {
      beatPulse = 1;
      lastBeatAt = now;
      elements.beatBadge.classList.add('is-detected');
      elements.beatStatus.textContent = t('beatDetected');
      window.clearTimeout(beatTimeout);
      beatTimeout = window.setTimeout(() => {
        if (!isDisposed && beatEnabled) {
          elements.beatBadge.classList.remove('is-detected');
          updateBeatLabel();
        }
      }, 190);
    }
  } else {
    beatLevel = 0;
  }
  beatPulse *= Math.exp(-delta * 5.6);
  ctx.restore();

  if (scheduleNext && !document.hidden && (isPlaying || !objectUrl)) animationFrame = window.requestAnimationFrame(drawFrame);
  else if (scheduleNext) animationFrame = 0;
}

function startAnimation(): void {
  if (!animationFrame && !isDisposed && !document.hidden) animationFrame = window.requestAnimationFrame(drawFrame);
}

function handleVisibilityChange(): void {
  if (document.hidden) {
    window.cancelAnimationFrame(animationFrame);
    animationFrame = 0;
    return;
  }
  if (!objectUrl || !elements.audio.paused) startAnimation();
  else drawFrame(performance.now(), false);
}

function chooseAudio(): void {
  elements.audioFile.click();
}

function exportSnapshot(): void {
  if (exportButton.disabled || isDisposed) return;
  exportButton.disabled = true;
  exportButton.setAttribute('aria-busy', 'true');
  try {
    elements.canvas.toBlob((blob) => {
      if (isDisposed) return;
      if (!blob) {
        showToast('exportFailed');
        exportButton.disabled = false;
        exportButton.removeAttribute('aria-busy');
        return;
      }
      try {
        if (exportedImageUrl) URL.revokeObjectURL(exportedImageUrl);
        exportedImageUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = exportedImageUrl;
        link.download = `vesper-visualizer-${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
        document.body.append(link);
        link.click();
        link.remove();
        window.clearTimeout(downloadTimeout);
        downloadTimeout = window.setTimeout(() => {
          if (!exportedImageUrl) return;
          URL.revokeObjectURL(exportedImageUrl);
          exportedImageUrl = null;
        }, 2000);
        showToast('exportSuccess');
      } catch (error) {
        console.error('The PNG snapshot could not be saved.', error);
        showToast('exportFailed');
      } finally {
        exportButton.disabled = false;
        exportButton.removeAttribute('aria-busy');
      }
    }, 'image/png');
  } catch (error) {
    console.error('The canvas could not be exported.', error);
    exportButton.disabled = false;
    exportButton.removeAttribute('aria-busy');
    showToast('exportFailed');
  }
}

function isAudioFile(file: File): boolean {
  return file.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|opus|flac|webm)$/i.test(file.name);
}

function loadFile(file: File | undefined): void {
  if (!file) return;
  if (!isAudioFile(file)) {
    showToast('unsupportedFile');
    return;
  }
  let nextObjectUrl: string;
  try {
    nextObjectUrl = URL.createObjectURL(file);
  } catch (error) {
    console.error('The selected audio file could not be opened.', error);
    showToast('fileLoadFailed');
    return;
  }
  elements.audio.pause();
  const previousObjectUrl = objectUrl;
  objectUrl = nextObjectUrl;
  elements.audio.src = nextObjectUrl;
  if (previousObjectUrl) URL.revokeObjectURL(previousObjectUrl);
  elements.audio.load();
  trackDurationText = '';
  elements.fileName.textContent = file.name;
  elements.playerTrackName.textContent = file.name;
  elements.loadedTrack.hidden = false;
  elements.dropZone.hidden = true;
  elements.emptyState.hidden = true;
  elements.playButton.disabled = false;
  elements.restartButton.disabled = false;
  elements.muteButton.disabled = false;
  elements.seekSlider.disabled = false;
  elements.volumeSlider.disabled = false;
  elements.seekSlider.value = '0';
  elements.audio.currentTime = 0;
  elements.durationTime.textContent = '00:00';
  elements.canvasDuration.textContent = '00:00';
  updateTime();
  updatePlaybackLabels();
  updateFileMetadata();
  startAnimation();
  showToast('fileLoaded');
}

async function togglePlayback(): Promise<void> {
  if (!objectUrl) {
    showToast('chooseAudio');
    return;
  }
  let context: AudioContext;
  try {
    context = getAudioGraph();
    if (context.state === 'suspended') await context.resume();
  } catch (error) {
    console.error('The audio engine could not initialize.', error);
    showToast(error instanceof Error && error.message === t('audioUnavailable') ? 'audioUnavailable' : 'contextFailed');
    return;
  }
  try {
    if (elements.audio.paused || elements.audio.ended) {
      if (elements.audio.ended) elements.audio.currentTime = 0;
      await elements.audio.play();
      startAnimation();
    } else {
      elements.audio.pause();
    }
    updatePlaybackLabels();
  } catch (error) {
    console.error('Playback could not start.', error);
    showToast('playFailed');
  }
}

function toggleSetting(button: HTMLButtonElement, currentlyEnabled: boolean, apply: (nextValue: boolean) => void): void {
  const nextValue = !currentlyEnabled;
  button.classList.toggle('is-on', nextValue);
  button.setAttribute('aria-checked', String(nextValue));
  apply(nextValue);
}

function bindEvents(): void {
  elements.uploadButton.addEventListener('click', chooseAudio, { signal });
  elements.emptyUploadButton.addEventListener('click', chooseAudio, { signal });
  elements.dropZone.addEventListener('click', chooseAudio, { signal });
  elements.replaceFileBtn.addEventListener('click', chooseAudio, { signal });
  elements.audioFile.addEventListener('change', () => {
    loadFile(elements.audioFile.files?.[0]);
    elements.audioFile.value = '';
  }, { signal });
  elements.dropZone.addEventListener('dragover', (event) => {
    event.preventDefault();
    elements.dropZone.classList.add('is-dragging');
  }, { signal });
  elements.dropZone.addEventListener('dragleave', (event) => {
    if (!(event.relatedTarget instanceof Node) || !elements.dropZone.contains(event.relatedTarget)) {
      elements.dropZone.classList.remove('is-dragging');
    }
  }, { signal });
  elements.dropZone.addEventListener('drop', (event) => {
    event.preventDefault();
    event.stopPropagation();
    elements.dropZone.classList.remove('is-dragging');
    elements.visualFrame.classList.remove('is-dragging');
    dropOverlay.classList.remove('is-active');
    loadFile(event.dataTransfer?.files[0]);
  }, { signal });
  elements.visualFrame.addEventListener('dragover', (event) => event.preventDefault(), { signal });
  elements.visualFrame.addEventListener('dragenter', (event) => {
    event.preventDefault();
    elements.visualFrame.classList.add('is-dragging');
    dropOverlay.classList.add('is-active');
  }, { signal });
  elements.visualFrame.addEventListener('dragleave', (event) => {
    if (!(event.relatedTarget instanceof Node) || !elements.visualFrame.contains(event.relatedTarget)) {
      elements.visualFrame.classList.remove('is-dragging');
      dropOverlay.classList.remove('is-active');
    }
  }, { signal });
  elements.visualFrame.addEventListener('drop', (event) => {
    event.preventDefault();
    elements.visualFrame.classList.remove('is-dragging');
    dropOverlay.classList.remove('is-active');
    loadFile(event.dataTransfer?.files[0]);
  }, { signal });
  elements.languageToggle.addEventListener('click', () => {
    language = language === 'en' ? 'zh' : 'en';
    applyLanguage();
  }, { signal });
  exportButton.addEventListener('click', exportSnapshot, { signal });
  document.addEventListener('visibilitychange', handleVisibilityChange, { signal });
  window.addEventListener('resize', updateCanvasSize, { signal });
  document.querySelectorAll<HTMLButtonElement>('.theme-card').forEach((button) => {
    button.addEventListener('click', () => {
      const requestedTheme = button.dataset.theme as ThemeName | undefined;
      if (!requestedTheme || !(requestedTheme in themes)) return;
      applyTheme(requestedTheme);
      drawFrame(performance.now(), false);
    }, { signal });
  });
  elements.sensitivity.addEventListener('input', () => {
    sensitivity = Number(elements.sensitivity.value);
    elements.sensitivityValue.value = `${sensitivity.toFixed(2)}×`;
    elements.sensitivityValue.textContent = `${sensitivity.toFixed(2)}×`;
  }, { signal });
  elements.trailsToggle.addEventListener('click', () => {
    toggleSetting(elements.trailsToggle, trailsEnabled, (next) => { trailsEnabled = next; });
  }, { signal });
  elements.beatToggle.addEventListener('click', () => {
    toggleSetting(elements.beatToggle, beatEnabled, (next) => {
      beatEnabled = next;
      if (!next) elements.beatBadge.classList.remove('is-detected');
      updateBeatLabel();
    });
  }, { signal });
  elements.playButton.addEventListener('click', () => { void togglePlayback(); }, { signal });
  elements.restartButton.addEventListener('click', () => {
    if (!objectUrl) return;
    elements.audio.currentTime = 0;
    if (elements.audio.paused) void togglePlayback();
    updateTime();
  }, { signal });
  elements.audio.addEventListener('loadedmetadata', () => {
    trackDurationText = Number.isFinite(elements.audio.duration) ? formatTime(elements.audio.duration) : t('noDuration');
    updateFileMetadata();
    updateTime();
  }, { signal });
  elements.audio.addEventListener('timeupdate', updateTime, { signal });
  elements.audio.addEventListener('durationchange', updateTime, { signal });
  elements.audio.addEventListener('play', () => { updatePlaybackLabels(); startAnimation(); }, { signal });
  elements.audio.addEventListener('pause', () => { updatePlaybackLabels(); drawFrame(performance.now(), false); }, { signal });
  elements.audio.addEventListener('ended', () => { updatePlaybackLabels(); drawFrame(performance.now(), false); }, { signal });
  elements.audio.addEventListener('error', () => {
    if (objectUrl) showToast('loadFailed');
  }, { signal });
  elements.seekSlider.addEventListener('input', () => {
    const duration = elements.audio.duration;
    if (Number.isFinite(duration) && duration > 0) {
      elements.audio.currentTime = (Number(elements.seekSlider.value) / 1000) * duration;
      updateTime();
    }
  }, { signal });
  elements.muteButton.addEventListener('click', () => {
    elements.audio.muted = !elements.audio.muted;
    updateMuteControl();
    showToast(elements.audio.muted ? 'volumeMuted' : 'volumeRestored');
  }, { signal });
  elements.volumeSlider.addEventListener('input', () => {
    const volume = Number(elements.volumeSlider.value);
    elements.audio.muted = volume === 0;
    if (gainNode) gainNode.gain.setTargetAtTime(volume, audioContext?.currentTime ?? 0, 0.025);
    updateMuteControl();
  }, { signal });
  window.addEventListener('keydown', (event) => {
    if (event.code !== 'Space' || event.repeat || event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLButtonElement) return;
    event.preventDefault();
    void togglePlayback();
  }, { signal });
  window.addEventListener('error', (event) => {
    console.error('Unexpected page error.', event.error ?? event.message);
    showToast('genericError');
  }, { signal });
  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled asynchronous error.', event.reason);
    showToast('genericError');
  }, { signal });
  window.addEventListener('pagehide', cleanup, { signal, once: true });
}

function cleanup(): void {
  if (isDisposed) return;
  isDisposed = true;
  listenerController.abort();
  window.cancelAnimationFrame(animationFrame);
  window.clearTimeout(toastTimeout);
  window.clearTimeout(beatTimeout);
  window.clearTimeout(downloadTimeout);
  resizeObserver?.disconnect();
  resizeObserver = null;
  elements.audio.pause();
  elements.audio.removeAttribute('src');
  elements.audio.load();
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = null;
  if (exportedImageUrl) URL.revokeObjectURL(exportedImageUrl);
  exportedImageUrl = null;
  try { sourceNode?.disconnect(); } catch (error) { console.warn('Audio source was already disconnected.', error); }
  try { analyser?.disconnect(); } catch (error) { console.warn('Analyser was already disconnected.', error); }
  try { gainNode?.disconnect(); } catch (error) { console.warn('Audio output was already disconnected.', error); }
  const context = audioContext;
  audioContext = null;
  sourceNode = null;
  analyser = null;
  gainNode = null;
  frequencyData = null;
  waveformData = null;
  if (context && context.state !== 'closed') void context.close().catch((error: unknown) => console.warn('Audio context did not close cleanly.', error));
}

function initialize(): void {
  try {
    applyLanguage();
    bindEvents();
    applyTheme(activeTheme);
    resizeObserver = new ResizeObserver(updateCanvasSize);
    resizeObserver.observe(elements.visualFrame);
    updateCanvasSize();
    updateTime();
    updatePlaybackLabels();
  } catch (error) {
    console.error('Visualizer initialization failed.', error);
    elements.fatalMessage.textContent = error instanceof Error ? error.message : t('fatalCopy');
    elements.fatalPanel.hidden = false;
  }
}

initialize();
