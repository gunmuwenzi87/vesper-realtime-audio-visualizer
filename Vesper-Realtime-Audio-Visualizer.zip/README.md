# Vesper — Real-Time Audio Visualizer

A single-page audio visualizer built with TypeScript, native CSS, Canvas 2D, and the Web Audio API. Load a local track to see its live frequency spectrum and circular neon waveform move together. Beat detection responds to low-frequency transients, while optional waveform trails preserve a little light between frames.

## Run locally

Requires Node.js 20.19+ or 22.12+ for the bundled Vite 7 toolchain.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. No audio is uploaded; the selected file is read locally by the browser. The app has no runtime JavaScript dependencies. Google Fonts are optional and fall back to system fonts when offline.

After `npm run build`, open `dist/Vesper-Realtime-Audio-Visualizer.html` directly in a modern browser. The build inlines the app code and styles into one file, so the standalone copy works from a local folder without a web server.

## Use

- Load an audio file with the picker or drag it onto the track panel.
- Use play/pause, restart, seek, mute, and volume controls to manage playback.
- Choose one of four neon palettes and tune visual sensitivity.
- Toggle waveform trails and low-frequency beat detection independently.
- Drop a track anywhere over the visualization or export the current canvas as a device-pixel-ratio PNG snapshot.
- Switch between English and Simplified Chinese without reloading.

Supported formats depend on the browser's media decoder; MP3, WAV, M4A, AAC, OGG, Opus, FLAC, and WebM audio are accepted when the browser can play them.

## Validation

```sh
npm run typecheck
npm run build
```

The page owns and closes its `AudioContext`, disconnects Web Audio nodes, stops animation frames, revokes local object URLs, disconnects the resize observer, and aborts DOM event listeners on teardown.
