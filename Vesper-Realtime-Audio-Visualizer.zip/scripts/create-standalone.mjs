import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const outputDirectory = join(projectRoot, 'dist');
const entryPath = join(outputDirectory, 'index.html');
const entryHtml = await readFile(entryPath, 'utf8');
const stylesheetTags = [...entryHtml.matchAll(/<link\b(?=[^>]*\brel=["']stylesheet["'])[^>]*>/gi)];
const scriptTags = [...entryHtml.matchAll(/<script\b(?=[^>]*\btype=["']module["'])(?=[^>]*\bsrc=["']([^"']+)["'])[^>]*>\s*<\/script>/gi)];

if (stylesheetTags.length !== 1 || scriptTags.length !== 1) {
  throw new Error('Expected one bundled stylesheet and one JavaScript module in the Vite output.');
}

const stylesheetPath = stylesheetTags[0][0].match(/\bhref=["']([^"']+)["']/i)?.[1];
const scriptPath = scriptTags[0][1];
if (!stylesheetPath || !scriptPath) throw new Error('The Vite output is missing an asset path.');

const assetPath = (url) => join(outputDirectory, ...url.replace(/^\.\//, '').split('/'));
const stylesheet = await readFile(assetPath(stylesheetPath), 'utf8');
const script = await readFile(assetPath(scriptPath), 'utf8');
const standaloneHtml = entryHtml
  .replace(stylesheetTags[0][0], `<style>\n${stylesheet}\n</style>`)
  .replace(scriptTags[0][0], `<script type="module">\n${script}\n</script>`);
const standalonePath = join(outputDirectory, 'Vesper-Realtime-Audio-Visualizer.html');

await writeFile(standalonePath, standaloneHtml, 'utf8');
process.stdout.write(`Created ${standalonePath}\n`);
